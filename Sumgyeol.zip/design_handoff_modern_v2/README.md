# Handoff: 숨결(Sumgyeol) — 메인 랜딩 (Modern tone v2)

## Overview
숨결은 "잘 떠나는 법, 잘 기억되는 법"을 표방하는 추모 플랫폼입니다. 살아있는 동안 사진·일지·영상·편지를 모으고(모음), 그날이 오면 약속한 가족에게 자동으로 전달되며(보냄), 이후에도 디지털 액자·추모 페이지로 일상에 머무르는(머무름) 서비스입니다. 이 핸드오프는 메인 랜딩 페이지의 **현대(Modern) 톤** 시안을 Next.js 레포(`cnkim74/sumgyeol`)에 적용하기 위한 패키지입니다.

## About the Design Files
이 번들의 파일은 **HTML 프로토타입 + Next.js로 변환된 컴포넌트 참조본**입니다.
- `reference/` 폴더의 HTML/JSX/CSS는 디자인 의도를 보여주는 **시각 레퍼런스**입니다 — 그대로 배포할 코드가 아닙니다.
- `app/`, `components/` 폴더는 시안을 레포의 기존 구조(Next.js 14 App Router + TSX)에 맞춰 **이미 변환해둔 산출물**입니다. 레포에 그대로 덮어쓰면 동작합니다.

기존 레포에 동일 이름의 컴포넌트가 있을 경우, 이 번들이 우선합니다 — 변환 시 props 시그니처와 라우팅 경로(`/#모음`, `/#사전신청` 등)를 기존과 호환되도록 유지했습니다.

## Fidelity
**High-fidelity (hifi)**. 색상·타이포·간격·인터랙션이 모두 결정된 상태입니다. 시안의 hex 값과 spacing을 그대로 사용해 주세요.

## Target environment
- **Framework**: Next.js 14+ (App Router), React 18, TypeScript
- **Styling**: 글로벌 CSS + CSS 변수 (Tailwind/CSS-in-JS 미사용). 기존 레포 패턴 그대로 따름.
- **Fonts**: Google Fonts(Noto Serif KR, JetBrains Mono) + jsdelivr(Pretendard Variable) — `app/layout.tsx`의 `<head>`에서 로드

## Files in this bundle

### 레포에 덮어쓸 파일 (`app/`, `components/`)
| 경로 | 역할 | 신규/수정 |
|---|---|---|
| `app/globals.css` | 디자인 토큰 + 타이포 + 컴포넌트 스타일 통합 | **수정** (전체 교체) |
| `app/layout.tsx` | 폰트 로드 + `data-mode="dark"` | **수정** |
| `app/page.tsx` | 새 섹션 구성 — DB 슬라이드 호출 제거 | **수정** |
| `components/HeroSlider.tsx` | 5슬라이드 캐러셀 (별·노을·편지·액자·벚꽃) | **수정** (전체 교체) |
| `components/HeroMood.tsx` | 5가지 무드 배경 컴포넌트 | **신규** |
| `components/Starfield.tsx` | SVG 별 + twinkle 애니메이션 | **신규** |
| `components/PortraitSilhouette.tsx` | 영정 실루엣 SVG | **신규** |
| `components/icons.tsx` | Arrow / ArrowLeft / Play / Lock 아이콘 | **신규** |
| `components/Header.tsx` | 상단 nav (sticky + blur) | **신규** (기존 `HeaderClient.tsx`를 대체) |
| `components/Footer.tsx` | 4컬럼 푸터 | **수정** |
| `components/Promise.tsx` | "한 문장" 섹션 | **수정** |
| `components/ThreeActs.tsx` | 모음·보냄·머무름 3컬럼 그리드 | **수정** |
| `components/Trust.tsx` | "약속" 4컬럼 라인 그리드 | **수정** |
| `components/Subscription.tsx` | 사전신청 이메일 폼 | **수정** |

### 기존 레포에서 더 이상 쓰지 않는 컴포넌트 (삭제 또는 그대로 둠)
- `components/HeaderClient.tsx` — `Header.tsx`로 대체
- `components/Hero.tsx`, `Showcase.tsx`, `VideoPaths.tsx` — 새 `page.tsx`에서 import 제거됨. 빌드는 정상이지만 정리하시려면 삭제 가능

### 참조용 디자인 파일 (`reference/`)
- `Sumgyeol Design v2.html` — 라이브 프로토타입 (열어보면 캐러셀 동작 확인 가능)
- `landing.jsx` — 시안 단계의 React 코드 (변환 전 원본)
- `primitives.jsx` — 시안용 atomic 컴포넌트 모음
- `styles.css` — 시안 단계 CSS (globals.css와 거의 동일)

---

## Design Tokens

### Color (CSS variables, dark mode default)
```css
--bg: #15171b;          /* 페이지 배경 */
--bg-elev: #1c1f25;     /* 카드 배경 */
--bg-soft: #181b20;     /* 섹션 변주 배경 */
--bg-deep: #0f1115;     /* 가장 깊은 배경 (그라디언트 끝) */

--ink: #e9ebee;         /* 본문 텍스트 */
--ink-2: #aeb4bd;       /* 보조 텍스트 */
--ink-3: #777e89;       /* 캡션 */
--ink-mute: #4a505a;    /* 메타·라벨 */

--rule: #262a31;        /* 1차 라인 */
--rule-2: #353a44;      /* 2차 라인 (카드 보더 hover) */
--rule-3: #454b56;      /* 3차 라인 (강조) */

--accent: #9aa6b5;      /* 청회 — 키 액센트 */
--accent-2: #6b7889;
--accent-warm: #c2b69a; /* 호박빛 따뜻함 — 절제 사용 */
```
라이트 모드(`[data-mode="light"]`)는 동일 토큰을 반전. `app/globals.css` 참고.

### Typography scale
| 클래스 | family | size | weight | line-height | tracking |
|---|---|---|---|---|---|
| `.t-display` | serif | clamp(44, 6.6vw, 92)px | 400 | 1.08 | -0.022em |
| `.t-h1` | serif | clamp(34, 4.6vw, 60)px | 400 | 1.16 | -0.014em |
| `.t-h2` | serif | clamp(26, 3vw, 38)px | 400 | 1.24 | -0.008em |
| `.t-h3` | serif | 20px | 500 | 1.36 | -0.005em |
| `.t-lead` | serif | clamp(17, 1.5vw, 21)px | 300 | 1.78 | -0.005em |
| `.t-body` | sans | 15px | 400 | 1.72 | -0.003em |
| `.t-caption` | sans | 13px | 400 | 1.6 | 0.005em |
| `.t-meta` | sans | 11.5px | 500 | 1.4 | 0.08em UPPER |
| `.kicker` | sans | 11px | 600 | — | 0.22em UPPER |

세리프는 `Noto Serif KR`, 산세리프는 `Pretendard Variable`, 모노는 `JetBrains Mono`. 모든 본문에 `word-break: keep-all` 적용 (한국어 어절 단위 줄바꿈).

### Spacing / radius
- 컨테이너: `max-width: 1200px`, gutter `clamp(20, 4vw, 56)px`
- 섹션 padding: 120–140px (수직)
- radius: small 8px, default 14px, large 22px

### Shadows
- soft: `0 1px 2px rgba(0,0,0,.4), 0 8px 24px rgba(0,0,0,.3)`
- deep: `0 30px 80px -20px rgba(0,0,0,.6)`

---

## Screens / Sections (Landing page)

### 1. Header (sticky)
- 높이 60px, blur(20px) 배경, 하단 1px 라인
- 좌측: 로고마크(원+호) + "숨결" (세리프 18px)
- 중앙: nav 링크 5개 — `모음 / 보냄 / 머무름 / 영상 / 소개`
- 우측: "로그인" + "시작하기" 필 버튼
- 모든 링크에 `white-space: nowrap` 필수 (한자/한글 단어 줄바꿈 방지)

### 2. Hero — 5슬라이드 풀스크린 캐러셀
- 높이 `min(100vh, 880px)`, minHeight 640px
- 5개 무드(stars / horizon / letter / frame / cherry)가 1.2초 페이드로 교차
- 자동 전환 6500ms (마우스 호버 시 일시정지, `prefers-reduced-motion` 시 정지)
- 하단 좌측: 진행 인디케이터(활성 32×2px / 비활성 18×2px) + "01 / 05" mono 카운터
- 하단 우측: 다음 슬라이드 키커 라벨 + ◀▶ 원형 버튼(40×40)
- 카피는 슬라이드별로 다른 키커/타이틀(2줄, 둘째 줄 italic + ink-2)/리드(2줄)/CTA 2개
- 각 슬라이드 정의는 `HeroSlider.tsx`의 `HERO_SLIDES` 상수 참고

#### Mood 배경 상세
- **stars**: 깊은 밤하늘 그라디언트 + Starfield 90개(twinkle 4s) + 하단 수평선
- **horizon**: 따뜻한 호박빛 오브 + 산 실루엣 SVG + 수평 라인
- **letter**: 거대한 `遺` 한자 워터마크 (accent 6% opacity) + 32×32 도트 그리드
- **frame**: 떠 있는 액자 3개(중앙 220px, 양옆 170px, 살짝 회전 ±2°), `追慕` 캡션
- **cherry**: 분홍빛 글로우 + 24개 SVG 꽃잎 (랜덤 위치/회전/스케일)

### 3. Promise — "한 문장"
- padding 140px 0
- max-width 920px, 좌측 정렬
- kicker "한 문장" + t-h1 4줄 (3행은 ink-3 색)

### 4. ThreeActs — 모음·보냄·머무름 (id="모음")
- 배경 `bg-soft`, 상하 1px 라인
- 상단: 좌측 t-h1 "모음 · 보냄 · 머무름." / 우측 t-body 설명 (2컬럼 align:end)
- 하단: 3컬럼 라인 그리드 (각 막마다 kicker / when / 제목 / 4개 항목)
- 항목 앞에 14px accent 색 짧은 라인

### 5. Trust — "약속"
- padding 120px 0, 상단 라인
- 4컬럼 라인 그리드 (라벨 + 한 줄 카피)
- 라벨은 accent 색 kicker, 카피는 17px serif

### 6. Subscription — 사전 신청 (id="사전신청")
- 배경 `bg-soft`, 상단 라인, padding 140px 0
- 가운데 정렬 — kicker / t-h1 / t-lead / 이메일 input + 초대장 받기 버튼 / 캡션
- input은 fill `bg-elev`, 1px `rule-2`, 999px radius

### 7. Footer
- 4컬럼 그리드(1.6fr 1fr 1fr 1fr) — 브랜드 + 서비스/파트너십/숨결 링크 그룹
- 하단 라인 위에 카피라이트 + "A breath, kept." italic

---

## Interactions & Behavior

### Carousel (HeroSlider)
- **Auto-advance**: 6500ms timeout, idx 의존
- **Pause on hover**: `setPaused(true/false)` on `onMouseEnter/Leave`
- **Reduced motion**: `prefers-reduced-motion: reduce` 매치 시 자동 전환 정지
- **Click indicator**: idx로 직접 점프
- **Arrows**: prev/next, 모듈러 인덱싱
- **Crossfade**: 1.2s opacity transition, 비활성 슬라이드는 `pointerEvents: none`
- **Re-animate text**: `<div key={slide.id}>`로 슬라이드 변경 시 fade-up 재생

### Form (Subscription)
- `onSubmit={(e) => e.preventDefault()}` — 실제 백엔드 연결은 별도 작업 필요
- 기존 레포에 사전신청 API 있으면 fetch 추가

### Buttons
- `.btn` 베이스 + `.btn-primary` (ink 배경) / `.btn-ghost` (테두리만) / `.btn-quiet` (배경 없음)
- hover 시 `translateY(-1px)` + box-shadow

---

## State Management
- **HeroSlider**: 로컬 `useState` — `idx`(현재 슬라이드), `paused`(호버 정지)
- **Subscription**: 로컬 `useState` (이메일) — 백엔드 연결 시 추가
- 글로벌 상태 불필요. DB·CMS 연결 없이 동작함.

---

## Implementation notes (for the developer)

1. **글꼴 로드 순서**: `app/layout.tsx`의 `<head>`에 Noto Serif KR → Pretendard → JetBrains Mono 순서. 기존 Noto Sans KR 링크는 제거됨.

2. **`data-mode` 속성**: `<body data-mode="dark">`. 라이트 토글 추가하려면 클라이언트 컴포넌트에서 `document.body.dataset.mode = "light"` 토글.

3. **DB 슬라이드 미사용**: 기존 `app/page.tsx`의 `listSlides()` 호출이 제거되었습니다. DB로 이미지를 관리하고 싶으시면 `HeroSlider`에 `imagePath` props를 받는 구조로 확장 — 각 슬라이드에 `mood` 컬럼 추가 후 DB 이미지를 무드 위에 겹치는 방식 추천.

4. **id 앵커 보존**: 기존 nav의 `#모음`, `#사전신청`, `#영상미리보기`, `#소개` 등 한국어 ID를 그대로 사용. URL escape 필요 없음 — Next.js Link가 자동 처리.

5. **사용 안 하는 컴포넌트**: 기존 `Hero.tsx`, `Showcase.tsx`, `VideoPaths.tsx`, `HeaderClient.tsx`는 새 `page.tsx`에서 import하지 않습니다. 빌드는 정상이지만 정리를 원하시면 삭제 가능.

6. **타입 안정**: 모든 컴포넌트가 TSX, props 타입 명시. `HeroSlider`는 기존 호출 시그니처(`<HeroSlider slides={items} />`) 호환을 위해 옵셔널 props만 받음 (현재는 미사용).

7. **테스트 체크리스트**:
   - [ ] `npm run build` 통과
   - [ ] 5슬라이드 캐러셀 자동 전환
   - [ ] 인디케이터 클릭 점프
   - [ ] 좌우 화살표 동작
   - [ ] 한국어 nav 링크 줄바꿈 안됨
   - [ ] 모바일 뷰포트(360–414px)에서 t-display가 깨지지 않음
   - [ ] `prefers-reduced-motion: reduce` 시 별 twinkle / 캐러셀 자동 전환 정지

---

## Assets
- 외부 이미지·폰트 파일 없음 (모든 비주얼은 SVG·CSS 그라디언트로 구현)
- `Logomark.tsx`(기존 레포에 이미 존재) 그대로 사용
- 한자 글리프(`遺`, `追慕`)는 시스템 폰트 렌더링

---

## Known caveats / next steps
- 영상 미리보기 섹션(`VideoPaths`) 변환은 이번 핸드오프에 미포함 — 필요 시 추가 요청
- 부고 작성, 추모 페이지, 영정사진, 유언장 등 **제품 내부 화면**은 시안만 있고 변환 미포함 (`reference/Sumgyeol Design v2.html`에서 확인)
- 라이트 모드 토글 UI 미구현 (토큰은 준비됨, 토글 컴포넌트만 추가하면 됨)
