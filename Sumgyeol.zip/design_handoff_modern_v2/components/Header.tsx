import Link from "next/link";
import Logomark from "./Logomark";

export default function Header() {
  return (
    <header className="nav">
      <div className="nav-inner">
        <Link className="nav-brand" href="/">
          <Logomark size={20} />
          <span>숨결</span>
        </Link>
        <nav className="nav-links" aria-label="주요">
          <Link className="nav-link" href="/#모음">모음</Link>
          <Link className="nav-link" href="/#보냄">보냄</Link>
          <Link className="nav-link" href="/#머무름">머무름</Link>
          <Link className="nav-link" href="/#영상미리보기">영상</Link>
          <Link className="nav-link" href="/#소개">소개</Link>
        </nav>
        <div style={{ display: "flex", gap: 18, alignItems: "center" }}>
          <Link className="nav-link" href="/login">로그인</Link>
          <Link className="nav-cta" href="/#사전신청">시작하기</Link>
        </div>
      </div>
    </header>
  );
}
