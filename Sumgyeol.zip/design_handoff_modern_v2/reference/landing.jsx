/* Sumgyeol — Landing v2 (Modern tone, refined)
   - 별빛 제거 → 라인·그리드·여백
   - 한자 액센트 절제, 작게
   - 더 넓은 여백, 차분한 리듬
*/

const { useState: useS2, useEffect: useE2, useRef: useR2, useMemo: useM2 } = React;

/* ──────────────────────────────────────────────────────────
   Hero — fullscreen slide carousel
   각 슬라이드마다 다른 무드 / 카피 / CTA
   ────────────────────────────────────────────────────────── */

const HERO_SLIDES = [
  {
    id: "stars",
    kicker: "SUMGYEOL · 숨결",
    title: ["잘 떠나는 법,", "잘 기억되는 법."],
    titleItalic: 1,  // index of italic line
    lead: "내 마지막 장(章)을 내가 씁니다.\n사진 한 장이면 시작할 수 있어요.",
    primary: { label: "영상 한 편 만들어 보기", href: "#" },
    secondary: { label: "어떻게 쓰나요", href: "#" },
    mood: "stars",
  },
  {
    id: "horizon",
    kicker: "ACT 1 · 모음",
    title: ["살아있는 동안,", "차곡차곡 쌓아갑니다."],
    titleItalic: 1,
    lead: "사진과 일지, 영상과 편지.\n흩어진 시간을 한곳에 모아둡니다.",
    primary: { label: "내 숨결함 만들기", href: "#" },
    secondary: { label: "어떻게 쌓이나요", href: "#" },
    mood: "horizon",
  },
  {
    id: "letter",
    kicker: "차별화 · 디지털 유언장",
    title: ["남기는 이야기,", "나만의 마지막 편지."],
    titleItalic: 1,
    lead: "수신인별로 다른 편지,\n약속된 날에 자동으로 전해집니다.",
    primary: { label: "유언장 써보기", href: "#" },
    secondary: { label: "예시 보기", href: "#" },
    mood: "letter",
  },
  {
    id: "frame",
    kicker: "ACT 3 · 머무름",
    title: ["떠난 후에도,", "일상 가까이에 머무릅니다."],
    titleItalic: 1,
    lead: "하늘공원의 디지털 액자,\n가족이 이어 쓰는 일지.",
    primary: { label: "추모 페이지 둘러보기", href: "#" },
    secondary: { label: "파트너십", href: "#" },
    mood: "frame",
  },
  {
    id: "cherry",
    kicker: "AI 추모 영상 · 30초",
    title: ["사진 세 장으로,", "한 편의 영상이 됩니다."],
    titleItalic: 1,
    lead: "AI가 음악과 흐름을 얹어 줍니다.\n무료로 한 편 만들어 보세요.",
    primary: { label: "지금 만들어 보기", href: "#" },
    secondary: { label: "샘플 영상", href: "#" },
    mood: "cherry",
  },
];

/* ── Mood backgrounds — each slide gets a distinct visual ── */
function HeroMood({ mood }) {
  if (mood === "stars") return <MoodStars />;
  if (mood === "horizon") return <MoodHorizon />;
  if (mood === "letter") return <MoodLetter />;
  if (mood === "frame") return <MoodFrame />;
  if (mood === "cherry") return <MoodCherry />;
  return null;
}

function MoodStars() {
  return (
    <>
      <div style={{
        position: "absolute", inset: 0,
        background: "radial-gradient(ellipse 100% 70% at 70% 20%, color-mix(in srgb, var(--accent) 14%, transparent) 0%, transparent 65%), linear-gradient(180deg, var(--bg-deep) 0%, var(--bg) 80%)",
      }} />
      <Starfield density={90} />
      {/* subtle horizon */}
      <div style={{
        position: "absolute", left: 0, right: 0, bottom: "0%",
        height: 1, background: "linear-gradient(90deg, transparent, color-mix(in srgb, var(--accent) 50%, transparent), transparent)",
      }} />
    </>
  );
}

function MoodHorizon() {
  return (
    <>
      <div style={{
        position: "absolute", inset: 0,
        background: "linear-gradient(180deg, var(--bg-deep) 0%, color-mix(in srgb, var(--accent-warm) 4%, var(--bg)) 60%, var(--bg) 100%)",
      }} />
      {/* warm low-light orb (sunset-ish but minimal) */}
      <div style={{
        position: "absolute", right: "8%", top: "55%", transform: "translateY(-50%)",
        width: 320, height: 320, borderRadius: "50%",
        background: "radial-gradient(circle, color-mix(in srgb, var(--accent-warm) 28%, transparent) 0%, transparent 70%)",
        filter: "blur(8px)",
      }} />
      {/* horizon line */}
      <div style={{
        position: "absolute", left: 0, right: 0, top: "70%",
        height: 1, background: "linear-gradient(90deg, transparent, var(--rule-2), transparent)",
      }} />
      {/* faint mountain silhouette */}
      <svg style={{ position: "absolute", left: 0, right: 0, bottom: 0, width: "100%", height: "30%", opacity: 0.4 }} viewBox="0 0 1200 200" preserveAspectRatio="none">
        <path d="M0,200 L0,140 L150,80 L300,120 L480,60 L640,110 L820,40 L1000,90 L1200,70 L1200,200 Z" fill="var(--bg-deep)" />
      </svg>
    </>
  );
}

function MoodLetter() {
  return (
    <>
      <div style={{
        position: "absolute", inset: 0,
        background: "linear-gradient(180deg, var(--bg) 0%, var(--bg-soft) 100%)",
      }} />
      {/* large 遺 character watermark */}
      <div style={{
        position: "absolute", right: "6%", top: "50%", transform: "translateY(-50%)",
        fontSize: "min(36vw, 540px)",
        fontFamily: "var(--serif)",
        color: "color-mix(in srgb, var(--accent) 6%, transparent)",
        lineHeight: 0.9,
        userSelect: "none",
        pointerEvents: "none",
      }}>遺</div>
      {/* paper grain via dotted grid */}
      <div style={{
        position: "absolute", inset: 0,
        backgroundImage: "radial-gradient(var(--rule) 1px, transparent 1px)",
        backgroundSize: "32px 32px",
        opacity: 0.5,
      }} />
    </>
  );
}

function MoodFrame() {
  return (
    <>
      <div style={{
        position: "absolute", inset: 0,
        background: "linear-gradient(180deg, var(--bg) 0%, var(--bg-deep) 100%)",
      }} />
      {/* a row of 3 floating frames */}
      <div style={{
        position: "absolute", right: "6%", top: "50%", transform: "translateY(-50%)",
        display: "flex", gap: 18, alignItems: "center",
        opacity: 0.85,
      }}>
        {[0,1,2].map(i => (
          <div key={i} style={{
            width: i === 1 ? 220 : 170,
            transform: `translateY(${i === 1 ? 0 : (i === 0 ? 14 : -14)}px) rotate(${i === 0 ? -2 : i === 2 ? 2 : 0}deg)`,
          }}>
            <div style={{
              padding: 10,
              background: "var(--bg-elev)",
              border: "1px solid var(--rule-2)",
              boxShadow: "0 20px 40px rgba(0,0,0,0.4)",
            }}>
              <div style={{
                aspectRatio: "3/4",
                background: "linear-gradient(180deg, var(--bg-soft), var(--bg-deep))",
                display: "grid", placeItems: "center",
              }}>
                <PortraitSilhouette size={i === 1 ? 140 : 100} />
              </div>
              <div style={{ height: 18, paddingTop: 6, fontFamily: "var(--serif)", fontSize: 9, color: "var(--ink-3)", textAlign: "center", letterSpacing: "0.2em" }}>
                追 慕
              </div>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

function MoodCherry() {
  // soft cherry-blossom mood: pinkish glow + scattered petals (svg)
  const petals = useM2(() => {
    const arr = [];
    for (let i = 0; i < 24; i++) {
      arr.push({
        x: Math.random() * 100,
        y: Math.random() * 100,
        s: Math.random() * 0.7 + 0.5,
        r: Math.random() * 360,
        op: Math.random() * 0.5 + 0.2,
      });
    }
    return arr;
  }, []);
  return (
    <>
      <div style={{
        position: "absolute", inset: 0,
        background: "radial-gradient(ellipse 60% 50% at 30% 30%, color-mix(in srgb, #d4a5a5 12%, transparent) 0%, transparent 60%), linear-gradient(180deg, var(--bg) 0%, var(--bg-deep) 100%)",
      }} />
      <svg style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}>
        {petals.map((p, i) => (
          <g key={i} transform={`translate(${p.x}% ${p.y}%) scale(${p.s}) rotate(${p.r})`} opacity={p.op}>
            <path d="M0,-6 C3,-4 4,0 0,6 C-4,0 -3,-4 0,-6 Z" fill="#d4a5a5" />
          </g>
        ))}
      </svg>
    </>
  );
}

function HeroSection() {
  const [idx, setIdx] = useS2(0);
  const [paused, setPaused] = useS2(false);
  const total = HERO_SLIDES.length;

  // Auto-advance every 6s
  useE2(() => {
    if (paused) return;
    const t = setTimeout(() => setIdx(i => (i + 1) % total), 6500);
    return () => clearTimeout(t);
  }, [idx, paused, total]);

  const go = (n) => setIdx((n + total) % total);
  const slide = HERO_SLIDES[idx];

  return (
    <section
      style={{
        position: "relative",
        overflow: "hidden",
        height: "min(100vh, 880px)",
        minHeight: 640,
        borderBottom: "1px solid var(--rule)",
      }}
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      {/* Stacked moods, fade between them */}
      {HERO_SLIDES.map((s, i) => (
        <div
          key={s.id}
          style={{
            position: "absolute", inset: 0,
            opacity: i === idx ? 1 : 0,
            transition: "opacity 1.2s ease",
            pointerEvents: i === idx ? "auto" : "none",
          }}
        >
          <HeroMood mood={s.mood} />
        </div>
      ))}

      {/* Bottom gradient for legibility */}
      <div style={{
        position: "absolute", inset: 0,
        background: "linear-gradient(180deg, transparent 50%, color-mix(in srgb, var(--bg) 60%, transparent) 100%)",
        pointerEvents: "none",
      }} />

      {/* Copy block — re-keyed on idx so it re-animates */}
      <div className="container" style={{
        position: "relative", height: "100%",
        display: "flex", flexDirection: "column", justifyContent: "center",
        maxWidth: 1100,
      }}>
        <div key={slide.id} style={{ maxWidth: 720 }}>
          <div className="kicker fade-up" style={{ marginBottom: 28, color: slide.mood === "cherry" ? "#d4a5a5" : "var(--ink-3)" }}>
            {slide.kicker}
          </div>
          <h1 className="t-display serif fade-up d1">
            {slide.title.map((line, i) => (
              <React.Fragment key={i}>
                {i === slide.titleItalic ? (
                  <span style={{ color: "var(--ink-2)", fontStyle: "italic", fontWeight: 300 }}>{line}</span>
                ) : line}
                {i < slide.title.length - 1 && <br/>}
              </React.Fragment>
            ))}
          </h1>
          <p className="t-lead fade-up d2" style={{ marginTop: 32, maxWidth: 540, whiteSpace: "pre-line" }}>
            {slide.lead}
          </p>
          <div className="fade-up d3" style={{ marginTop: 44, display: "flex", gap: 12, flexWrap: "wrap" }}>
            <a className="btn btn-primary" href={slide.primary.href}>
              {slide.primary.label} <Icon.Arrow />
            </a>
            <a className="btn btn-quiet" href={slide.secondary.href}>{slide.secondary.label}</a>
          </div>
        </div>
      </div>

      {/* Carousel chrome — bottom bar */}
      <div style={{
        position: "absolute", left: 0, right: 0, bottom: 0,
        padding: "0 var(--gutter) 32px",
        maxWidth: "var(--measure)", margin: "0 auto",
      }}>
        <div style={{
          display: "flex", alignItems: "center", justifyContent: "space-between",
          gap: 24,
        }}>
          {/* Slide indicators (left) */}
          <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
            {HERO_SLIDES.map((_, i) => (
              <button
                key={i}
                onClick={() => go(i)}
                aria-label={`슬라이드 ${i+1}`}
                style={{
                  width: i === idx ? 32 : 18,
                  height: 2,
                  background: i === idx ? "var(--ink)" : "var(--rule-3)",
                  border: "none",
                  padding: 0,
                  cursor: "pointer",
                  transition: "all .4s ease",
                  borderRadius: 1,
                }}
              />
            ))}
            <span className="t-meta" style={{ marginLeft: 16, fontFamily: "var(--mono)", color: "var(--ink-3)" }}>
              {String(idx + 1).padStart(2, "0")} / {String(total).padStart(2, "0")}
            </span>
          </div>

          {/* Arrows + label (right) */}
          <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
            <span className="t-meta" style={{ color: "var(--ink-3)" }}>{HERO_SLIDES[(idx + 1) % total].kicker}</span>
            <div style={{ display: "flex", gap: 6 }}>
              <button
                onClick={() => go(idx - 1)}
                aria-label="이전 슬라이드"
                style={{
                  width: 40, height: 40, borderRadius: "50%",
                  background: "transparent", border: "1px solid var(--rule-2)",
                  color: "var(--ink-2)", cursor: "pointer",
                  display: "grid", placeItems: "center",
                  transition: "all .15s ease",
                }}
                onMouseEnter={(e) => { e.currentTarget.style.borderColor = "var(--rule-3)"; e.currentTarget.style.color = "var(--ink)"; }}
                onMouseLeave={(e) => { e.currentTarget.style.borderColor = "var(--rule-2)"; e.currentTarget.style.color = "var(--ink-2)"; }}
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"><path d="M19 12H5M11 19l-7-7 7-7"/></svg>
              </button>
              <button
                onClick={() => go(idx + 1)}
                aria-label="다음 슬라이드"
                style={{
                  width: 40, height: 40, borderRadius: "50%",
                  background: "transparent", border: "1px solid var(--rule-2)",
                  color: "var(--ink-2)", cursor: "pointer",
                  display: "grid", placeItems: "center",
                  transition: "all .15s ease",
                }}
                onMouseEnter={(e) => { e.currentTarget.style.borderColor = "var(--rule-3)"; e.currentTarget.style.color = "var(--ink)"; }}
                onMouseLeave={(e) => { e.currentTarget.style.borderColor = "var(--rule-2)"; e.currentTarget.style.color = "var(--ink-2)"; }}
              >
                <Icon.Arrow size={14} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ── Promise — single sentence, big ───────────────────── */
function PromiseSection() {
  return (
    <section style={{ padding: "140px 0" }}>
      <div className="container" style={{ maxWidth: 920 }}>
        <div className="kicker" style={{ marginBottom: 32 }}>한 문장</div>
        <h2 className="t-h1 serif">
          숨결은 살아있는 동안 차곡차곡 쌓고,<br/>
          그날이 오면 가족에게 자동으로 전해지고,<br/>
          <span style={{ color: "var(--ink-3)" }}>이후에도 일상 가까이에 머무르는</span><br/>
          추모 플랫폼입니다.
        </h2>
      </div>
    </section>
  );
}

/* ── ThreeActs — minimal, structured columns ──────────── */
const acts = [
  { kicker: "ACT 1", title: "숨결을 모읍니다", when: "살아있는 동안",
    items: ["사진과 영상으로 만드는 추모 영상", "남기는 글, 매일의 일지", "가족에게 보낼 미래의 메시지", "부고 받을 사람 명단"] },
  { kicker: "ACT 2", title: "숨결을 보냅니다", when: "그날",
    items: ["부고 자동 SMS 발송", "추모 영상이 함께 도착", "디지털 조화 · 기념품", "상조회사·장례식장 연계"] },
  { kicker: "ACT 3", title: "숨결이 머무릅니다", when: "그 이후",
    items: ["하늘공원 디지털 액자", "추모 페이지 · 기일 알림", "AI로 다시 듣는 목소리", "가족이 이어 쓰는 일지"] },
];

function ThreeActsSection() {
  return (
    <section id="모음" style={{ padding: "120px 0", background: "var(--bg-soft)", borderTop: "1px solid var(--rule)", borderBottom: "1px solid var(--rule)" }}>
      <div className="container">
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", alignItems: "end", gap: 40, marginBottom: 80 }}>
          <div>
            <div className="kicker" style={{ marginBottom: 24 }}>서비스 — 세 막</div>
            <h2 className="t-h1 serif">
              모음 · 보냄 · 머무름.
            </h2>
          </div>
          <div className="t-body" style={{ paddingBottom: 8 }}>
            한 사람의 시간은 흐름입니다. 살아있는 동안 차곡차곡 쌓아두고, 그날이 오면 약속한 가족에게 보내고, 이후에도 일상 가까이에 머무르도록 — 세 막으로 설계했습니다.
          </div>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", borderTop: "1px solid var(--rule-2)" }}>
          {acts.map((act, i) => (
            <article key={i} style={{
              padding: "40px 32px 40px 0",
              borderRight: i < 2 ? "1px solid var(--rule)" : "none",
              paddingLeft: i > 0 ? 32 : 0,
              minHeight: 380,
              display: "flex", flexDirection: "column",
            }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 28 }}>
                <span className="kicker kicker-accent">{act.kicker}</span>
                <span className="t-meta">{act.when}</span>
              </div>
              <h3 className="t-h2 serif" style={{ marginBottom: 28 }}>{act.title}</h3>
              <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: 14, marginTop: "auto" }}>
                {act.items.map((item, j) => (
                  <li key={j} style={{ display: "flex", gap: 12, alignItems: "flex-start", color: "var(--ink-2)", fontSize: 15, lineHeight: 1.6 }}>
                    <span style={{ color: "var(--accent)", marginTop: 8, width: 14, height: 1, background: "currentColor", flexShrink: 0 }} />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ── Showcase — bento-ish grid ─────────────────────── */
function ShowcaseSection() {
  const cats = ["전체", "추모 페이지", "부고", "영상", "유언장", "액자"];
  const [active, setActive] = useS2("전체");
  const items = [
    { cat: "추모 페이지", title: "추모 페이지", caption: "고인을 기억하는 한 페이지. URL 하나로 평생 보관됩니다.",
      preview: <div style={{ display: "grid", placeItems: "center", height: "100%" }}><PortraitSilhouette size={130} ringed /></div> },
    { cat: "부고", title: "부고 카드", caption: "사진과 짧은 글을 담은 단정한 부고. 카톡·SMS로 전해집니다.",
      preview: (
        <div style={{ padding: 22, height: "100%", display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", gap: 12 }}>
          <PortraitSilhouette size={64} />
          <div style={{ textAlign: "center" }}>
            <div className="serif" style={{ fontSize: 13, color: "var(--ink-2)", letterSpacing: "0.4em" }}>訃 告</div>
            <div className="t-meta" style={{ marginTop: 4 }}>2026 · 04 · 14</div>
          </div>
        </div>
      ) },
    { cat: "영상", title: "AI 추모 영상", caption: "사진과 일지로 만드는 30초 추모 영상.",
      preview: (
        <div style={{ display: "grid", placeItems: "center", height: "100%", background: "var(--bg-deep)", borderRadius: 6 }}>
          <div style={{ width: 44, height: 44, borderRadius: "50%", border: "1px solid var(--rule-3)", display: "grid", placeItems: "center", color: "var(--ink-2)" }}><Icon.Play size={16} /></div>
        </div>
      ) },
    { cat: "유언장", title: "디지털 유언장", caption: "수신인별로 따로 남기는 마지막 편지.",
      preview: (
        <div style={{ padding: 18, fontFamily: "var(--serif)", color: "var(--ink-2)", height: "100%", display: "flex", flexDirection: "column", gap: 8, justifyContent: "center" }}>
          <div className="t-meta" style={{ letterSpacing: "0.5em" }}>遺 言</div>
          <div style={{ height: 1, background: "var(--rule)" }} />
          <div style={{ fontSize: 12.5, lineHeight: 1.7 }}>사랑하는 가족에게 —</div>
          <div style={{ height: 1, background: "var(--rule)", width: "60%" }} />
          <div style={{ height: 1, background: "var(--rule)", width: "80%" }} />
          <div style={{ height: 1, background: "var(--rule)", width: "40%" }} />
        </div>
      ) },
    { cat: "액자", title: "디지털 액자", caption: "하늘공원·집에 두는 액자. 사진과 영상이 차분히 흐릅니다.",
      preview: (
        <div style={{ display: "grid", placeItems: "center", height: "100%" }}>
          <div style={{ width: 120, height: 150, border: "1px solid var(--rule-2)", padding: 7, background: "var(--bg-deep)" }}>
            <PortraitSilhouette size={104} />
          </div>
        </div>
      ) },
    { cat: "추모 페이지", title: "사진 모음", caption: "흩어진 사진을 한곳에 모아 가족과 나누어 봅니다.",
      preview: (
        <div style={{ padding: 14, height: "100%", display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gridTemplateRows: "1fr 1fr", gap: 4 }}>
          {[1,2,3,4,5,6].map(i => <Photo key={i} shape="square" />)}
        </div>
      ) },
  ];
  const visible = active === "전체" ? items : items.filter(it => it.cat === active);

  return (
    <section style={{ padding: "120px 0" }}>
      <div className="container">
        <div style={{ marginBottom: 56 }}>
          <div className="kicker" style={{ marginBottom: 24 }}>결과물</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", alignItems: "end", gap: 40 }}>
            <h2 className="t-h1 serif">이렇게 남길 수 있어요.</h2>
            <p className="t-body" style={{ paddingBottom: 8 }}>
              한 장의 페이지부터 한 편의 다큐멘터리까지. 천천히, 한 번에 하나씩.
            </p>
          </div>
        </div>

        <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 40, paddingBottom: 16, borderBottom: "1px solid var(--rule)" }}>
          {cats.map(c => (
            <button
              key={c}
              onClick={() => setActive(c)}
              style={{
                padding: "8px 16px", borderRadius: 999, fontSize: 13,
                background: active === c ? "var(--ink)" : "transparent",
                color: active === c ? "var(--bg)" : "var(--ink-2)",
                border: "1px solid " + (active === c ? "var(--ink)" : "var(--rule-2)"),
                cursor: "pointer", fontFamily: "var(--sans)", fontWeight: 500,
                transition: "all .2s ease",
              }}
            >{c}</button>
          ))}
        </div>

        <div style={{ display: "grid", gap: 16, gridTemplateColumns: "repeat(3, 1fr)" }}>
          {visible.map((it, i) => (
            <article key={i} className="card" style={{ padding: 16, background: "var(--bg-elev)" }}>
              <div style={{
                aspectRatio: "4/3",
                background: "var(--bg-deep)",
                border: "1px solid var(--rule)",
                borderRadius: 8,
                overflow: "hidden",
              }}>
                {it.preview}
              </div>
              <div style={{ padding: "16px 8px 4px" }}>
                <h3 className="t-h3 serif">{it.title}</h3>
                <p className="t-body" style={{ marginTop: 8, fontSize: 13.5 }}>{it.caption}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ── VideoPaths ───────────────────────────────────── */
function VideoPathsSection() {
  return (
    <section id="영상" style={{ padding: "140px 0", background: "var(--bg-soft)", borderTop: "1px solid var(--rule)", borderBottom: "1px solid var(--rule)" }}>
      <div className="container">
        <div style={{ marginBottom: 64, maxWidth: 720 }}>
          <div className="kicker" style={{ marginBottom: 24 }}>영상 — 두 가지 길</div>
          <h2 className="t-h1 serif">
            한 사람의 이야기를<br/>
            <span style={{ fontStyle: "italic", color: "var(--ink-2)", fontWeight: 300 }}>두 가지 결</span>로 남깁니다.
          </h2>
        </div>

        <div style={{ display: "grid", gap: 16, gridTemplateColumns: "1fr 1fr" }}>
          <article className="card-flat" style={{ padding: 40, background: "var(--bg-elev)" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
              <div className="kicker kicker-accent">AI · 30초</div>
              <div className="t-meta">자동</div>
            </div>
            <h3 className="t-h2 serif" style={{ marginTop: 20 }}>혼자, 빠르게</h3>
            <p className="t-body" style={{ marginTop: 14 }}>
              사진 3장과 짧은 글이면 됩니다. AI가 음악과 흐름을 얹어, 30초의 추모 영상을 만들어 드려요.
            </p>
            <div style={{ marginTop: 32, aspectRatio: "16/9", background: "var(--bg-deep)", borderRadius: 12, position: "relative", overflow: "hidden", border: "1px solid var(--rule)" }}>
              <div style={{ position: "absolute", inset: 0, display: "grid", placeItems: "center" }}>
                <PortraitSilhouette size={100} />
              </div>
              <div style={{ position: "absolute", bottom: 12, left: 14, right: 14, display: "flex", alignItems: "center", gap: 10, color: "var(--ink-2)", fontSize: 11 }}>
                <Icon.Play size={12} />
                <div style={{ flex: 1, height: 2, background: "var(--rule-2)", borderRadius: 1 }}>
                  <div style={{ width: "32%", height: "100%", background: "var(--accent)" }} />
                </div>
                <span style={{ fontFamily: "var(--mono)" }}>0:09 / 0:30</span>
              </div>
            </div>
            <a className="btn btn-ghost btn-sm" href="#" style={{ marginTop: 24 }}>무료로 한 편 만들기 <Icon.Arrow size={13} /></a>
          </article>

          <article className="card-flat" style={{ padding: 40, background: "var(--bg-elev)" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
              <div className="kicker">다큐멘터리 · 인터뷰</div>
              <div className="t-meta">유료</div>
            </div>
            <h3 className="t-h2 serif" style={{ marginTop: 20 }}>함께, 깊이</h3>
            <p className="t-body" style={{ marginTop: 14 }}>
              지역 영상 크리에이터가 댁으로 찾아갑니다. 인터뷰와 일상을 담아 한 편의 다큐멘터리를 만듭니다.
            </p>
            <div style={{ marginTop: 32, display: "grid", gap: 6, gridTemplateColumns: "1.4fr 1fr" }}>
              <Photo shape="landscape" />
              <div style={{ display: "grid", gap: 6, gridTemplateRows: "1fr 1fr" }}>
                <Photo shape="landscape" />
                <Photo shape="landscape" />
              </div>
            </div>
            <a className="btn btn-ghost btn-sm" href="#" style={{ marginTop: 24 }}>크리에이터 찾기 <Icon.Arrow size={13} /></a>
          </article>
        </div>
      </div>
    </section>
  );
}

/* ── Will — differentiated ───────────────── */
function WillSection() {
  return (
    <section style={{ padding: "140px 0", position: "relative", overflow: "hidden" }}>
      <div className="container">
        <div style={{ display: "grid", gap: 80, gridTemplateColumns: "1fr 1fr", alignItems: "center" }}>
          <div>
            <div className="kicker kicker-warm" style={{ marginBottom: 24 }}>차별화 · 디지털 유언장</div>
            <h2 className="t-h1 serif">
              남기는 이야기,<br/>
              <span style={{ fontStyle: "italic", color: "var(--ink-2)", fontWeight: 300 }}>나만의 마지막 편지.</span>
            </h2>
            <p className="t-lead" style={{ marginTop: 28 }}>
              가족 한 사람 한 사람에게 따로 남길 수 있고,<br/>
              약속된 날에 자동으로 전해집니다.
            </p>
            <div style={{ marginTop: 40, display: "flex", flexDirection: "column" }}>
              {[
                "수신인별로 다른 편지 — 배우자, 자녀, 손자녀에게 따로",
                "약속된 날 자동 발송 — 1주기, 환갑, 결혼식 당일",
                "음성으로도 남기기 — 글이 어렵다면 목소리로",
                "비공개 잠금 — 그날까지는 본인만 봅니다",
              ].map((t, i) => (
                <div key={i} style={{
                  display: "flex", gap: 16, alignItems: "flex-start",
                  padding: "18px 0",
                  borderTop: "1px solid var(--rule)",
                  borderBottom: i === 3 ? "1px solid var(--rule)" : "none",
                  color: "var(--ink-2)",
                }}>
                  <span className="t-meta" style={{ minWidth: 24, color: "var(--ink-mute)", fontFamily: "var(--mono)" }}>
                    0{i+1}
                  </span>
                  <span style={{ fontSize: 15, lineHeight: 1.6, fontFamily: "var(--serif)", color: "var(--ink)" }}>{t}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Will preview */}
          <div style={{ position: "relative" }}>
            <div className="card-flat" style={{
              padding: "48px 44px",
              fontFamily: "var(--serif)",
              background: "var(--bg-elev)",
              boxShadow: "var(--shadow-deep)",
            }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
                <span className="t-meta" style={{ letterSpacing: "0.5em", color: "var(--accent)" }}>遺 · 言</span>
                <span className="t-meta">No. 003 · 아내에게</span>
              </div>
              <hr className="hairline" />
              <div style={{ marginTop: 28, fontSize: 15.5, lineHeight: 2, color: "var(--ink-2)", whiteSpace: "pre-wrap" }}>
{`혜진에게.

당신을 만난 1986년 봄, 그 벚꽃을
아직 기억합니다. 지난 사십 년, 당신이
아니었으면 나는 그저 어딘가의 이름 없는
사내로 살았을 거예요.

이 편지를 읽고 있다는 건 — 내가 먼저
갔다는 뜻이겠지요. 울지 마세요.
너무 오래 슬퍼하지도 마세요.

매년 봄마다, 그 벚꽃 길을 한 번씩
걸어 주면 나는 거기 있을 겁니다.`}
              </div>
              <hr className="hairline" style={{ marginTop: 32 }} />
              <div style={{ marginTop: 20, display: "flex", justifyContent: "space-between" }}>
                <div>
                  <div className="t-meta" style={{ marginBottom: 4 }}>전달 예정</div>
                  <div className="serif" style={{ fontSize: 14, color: "var(--ink)" }}>나의 기일 7일 후</div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div className="t-meta" style={{ marginBottom: 4 }}>작성</div>
                  <div className="serif" style={{ fontSize: 14, color: "var(--ink)" }}>2026.04.14</div>
                </div>
              </div>
            </div>

            <div style={{
              position: "absolute", top: -14, right: 16,
              background: "var(--bg)", border: "1px solid var(--rule-2)",
              borderRadius: 999, padding: "7px 13px",
              display: "flex", alignItems: "center", gap: 7,
              fontSize: 11.5, color: "var(--ink-2)",
              boxShadow: "var(--shadow-soft)",
              letterSpacing: "0.05em",
            }}>
              <Icon.Lock size={12} /> 그날까지 비공개
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ── Trust ──────────────────────────── */
function TrustSection() {
  const items = [
    { kicker: "보관", text: "한 번 만든 페이지는 평생 보관됩니다." },
    { kicker: "잠금", text: "그날 전까지는 본인만 볼 수 있어요." },
    { kicker: "전달", text: "약속한 사람에게, 약속한 날에." },
    { kicker: "해지", text: "마음이 바뀌면 모두 지울 수 있습니다." },
  ];
  return (
    <section style={{ padding: "120px 0", borderTop: "1px solid var(--rule)" }}>
      <div className="container">
        <div style={{ marginBottom: 56 }}>
          <div className="kicker" style={{ marginBottom: 24 }}>약속</div>
          <h2 className="t-h2 serif" style={{ maxWidth: 700 }}>마음을 맡기는 일이니까요.</h2>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", borderTop: "1px solid var(--rule)" }}>
          {items.map((it, i) => (
            <div key={i} style={{
              padding: "32px 28px 32px 0",
              borderRight: i < items.length - 1 ? "1px solid var(--rule)" : "none",
              paddingLeft: i > 0 ? 28 : 0,
            }}>
              <div className="kicker kicker-accent" style={{ marginBottom: 18 }}>{it.kicker}</div>
              <p className="serif" style={{ fontSize: 17, lineHeight: 1.5, color: "var(--ink)" }}>{it.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ── Waitlist ──────────────────────── */
function WaitlistSection() {
  return (
    <section id="사전신청" style={{ padding: "140px 0", background: "var(--bg-soft)", borderTop: "1px solid var(--rule)" }}>
      <div className="container" style={{ maxWidth: 720, textAlign: "center" }}>
        <div className="kicker" style={{ marginBottom: 24 }}>사전 신청</div>
        <h2 className="t-h1 serif">먼저 받아 보시겠어요?</h2>
        <p className="t-lead" style={{ marginTop: 24, maxWidth: 540, marginLeft: "auto", marginRight: "auto" }}>
          이메일을 남겨 주시면, 첫 베타 초대장을 가장 먼저 보내드립니다.
        </p>
        <form style={{ marginTop: 40, display: "flex", gap: 8, maxWidth: 460, margin: "40px auto 0", flexWrap: "wrap", justifyContent: "center" }} onSubmit={(e) => e.preventDefault()}>
          <input
            type="email"
            placeholder="이메일 주소"
            style={{
              flex: "1 1 240px",
              padding: "14px 20px",
              background: "var(--bg-elev)",
              border: "1px solid var(--rule-2)",
              borderRadius: 999,
              color: "var(--ink)",
              fontFamily: "var(--sans)",
              fontSize: 14.5,
              outline: "none",
            }}
          />
          <button className="btn btn-primary" type="submit">초대장 받기</button>
        </form>
        <p className="t-caption" style={{ marginTop: 18 }}>
          개인정보는 베타 초대 외의 용도로 사용되지 않습니다.
        </p>
      </div>
    </section>
  );
}

/* ── Footer ────────────────────── */
function FooterSection() {
  return (
    <footer style={{ borderTop: "1px solid var(--rule)", padding: "72px 0 36px" }}>
      <div className="container" style={{ display: "grid", gap: 48, gridTemplateColumns: "1.6fr 1fr 1fr 1fr" }}>
        <div>
          <a className="nav-brand" href="#"><Logomark size={22} /><span>숨결</span></a>
          <p className="serif" style={{ marginTop: 14, color: "var(--ink-2)", fontSize: 14, lineHeight: 1.7, maxWidth: 320 }}>
            잘 떠나는 법, 잘 기억되는 법.
          </p>
        </div>
        {[
          { h: "서비스", links: ["모음", "보냄", "머무름", "AI 추모 영상", "다큐멘터리"] },
          { h: "파트너십", links: ["상조회사·장례식장", "하늘공원 디지털 액자"] },
          { h: "숨결", links: ["소개", "도움말", "이용약관", "개인정보 처리방침"] },
        ].map((g, i) => (
          <div key={i}>
            <div className="kicker" style={{ marginBottom: 16 }}>{g.h}</div>
            <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: 10 }}>
              {g.links.map((l, j) => <li key={j}><a href="#" style={{ color: "var(--ink-2)", textDecoration: "none", fontSize: 14 }}>{l}</a></li>)}
            </ul>
          </div>
        ))}
      </div>
      <div className="container" style={{ marginTop: 56, paddingTop: 24, borderTop: "1px solid var(--rule)", display: "flex", justifyContent: "space-between" }}>
        <div className="t-meta">© 2026 숨결 (sumgyeol). All rights reserved.</div>
        <div className="serif" style={{ color: "var(--ink-3)", fontStyle: "italic", fontSize: 13 }}>A breath, kept.</div>
      </div>
    </footer>
  );
}

function LandingPage() {
  return (
    <div>
      <TopNav />
      <HeroSection />
      <PromiseSection />
      <ThreeActsSection />
      <ShowcaseSection />
      <VideoPathsSection />
      <WillSection />
      <TrustSection />
      <WaitlistSection />
      <FooterSection />
    </div>
  );
}

Object.assign(window, { LandingPage });
