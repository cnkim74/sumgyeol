/* Shared atomic components for Sumgyeol mockups */

const { useState, useEffect, useRef, useMemo } = React;

/* ──────────────────────────────────────────────────────────
   Logomark — a breath: small circle within a thin arc
   ────────────────────────────────────────────────────────── */
function Logomark({ size = 22, color = "currentColor" }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <circle cx="12" cy="12" r="10.5" stroke={color} strokeOpacity="0.35" strokeWidth="1" />
      <path
        d="M5 14c2.5-3 5-3 7-3s4.5 0 7-3"
        stroke={color}
        strokeWidth="1.2"
        strokeLinecap="round"
        fill="none"
      />
      <circle cx="12" cy="12" r="1.4" fill={color} />
    </svg>
  );
}

/* ──────────────────────────────────────────────────────────
   Top nav — Apple-ish, sticky, blurred
   ────────────────────────────────────────────────────────── */
function TopNav({ user = null, light = false }) {
  return (
    <header className="nav">
      <div className="nav-inner">
        <a className="nav-brand" href="#">
          <Logomark size={20} />
          <span>숨결</span>
        </a>
        <nav className="nav-links" aria-label="주요">
          <a className="nav-link" href="#">모음</a>
          <a className="nav-link" href="#">보냄</a>
          <a className="nav-link" href="#">머무름</a>
          <a className="nav-link" href="#">영상</a>
          <a className="nav-link" href="#">소개</a>
        </nav>
        <div style={{ display: "flex", gap: 18, alignItems: "center" }}>
          <a className="nav-link" href="#">로그인</a>
          <a className="nav-cta" href="#">시작하기</a>
        </div>
      </div>
    </header>
  );
}

/* ──────────────────────────────────────────────────────────
   Photo — abstracted portrait/landscape placeholder
   subtly evokes a soft-focus portrait without inventing imagery
   ────────────────────────────────────────────────────────── */
function Photo({ shape = "portrait", caption = null, glow = false, vignette = false, children, style = {}, className = "" }) {
  const cls = "photo photo-" + shape + " " + className;
  return (
    <div className={cls} style={style}>
      {glow && <div style={{
        position: "absolute", inset: "10% 15% 30% 15%",
        background: "radial-gradient(ellipse, color-mix(in srgb, var(--accent) 50%, transparent) 0%, transparent 70%)",
        filter: "blur(30px)",
      }} />}
      {vignette && <div style={{
        position: "absolute", inset: 0,
        background: "radial-gradient(ellipse at center, transparent 40%, rgba(0,0,0,0.5) 100%)",
      }} />}
      {children}
    </div>
  );
}

/* ──────────────────────────────────────────────────────────
   Portrait — silhouetted figure (no actual photo)
   For memorial frames; minimal, respectful
   ────────────────────────────────────────────────────────── */
function PortraitSilhouette({ size = 200, ringed = false }) {
  return (
    <svg width={size} height={size * 1.25} viewBox="0 0 200 250" aria-hidden="true">
      <defs>
        <linearGradient id="silbg" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="var(--accent)" stopOpacity="0.18" />
          <stop offset="1" stopColor="var(--bg-elev)" stopOpacity="1" />
        </linearGradient>
        <radialGradient id="silglow" cx="0.5" cy="0.4" r="0.5">
          <stop offset="0" stopColor="var(--accent)" stopOpacity="0.45" />
          <stop offset="1" stopColor="var(--accent)" stopOpacity="0" />
        </radialGradient>
      </defs>
      <rect width="200" height="250" fill="url(#silbg)" />
      <circle cx="100" cy="100" r="80" fill="url(#silglow)" />
      <ellipse cx="100" cy="98" rx="32" ry="38" fill="var(--ink-mute)" opacity="0.55" />
      <path d="M40 250c0-38 25-72 60-72s60 34 60 72" fill="var(--ink-mute)" opacity="0.55" />
      {ringed && (
        <rect x="6" y="6" width="188" height="238" fill="none" stroke="var(--accent)" strokeOpacity="0.6" strokeWidth="0.8" />
      )}
    </svg>
  );
}

/* ──────────────────────────────────────────────────────────
   Starfield background (for hero / memorial spaces)
   ────────────────────────────────────────────────────────── */
function Starfield({ density = 80, twinkle = true }) {
  const stars = useMemo(() => {
    const arr = [];
    for (let i = 0; i < density; i++) {
      arr.push({
        x: Math.random() * 100,
        y: Math.random() * 100,
        r: Math.random() * 1.4 + 0.3,
        op: Math.random() * 0.6 + 0.2,
        delay: Math.random() * 4,
      });
    }
    return arr;
  }, [density]);
  return (
    <svg style={{ position: "absolute", inset: 0, width: "100%", height: "100%", pointerEvents: "none" }}>
      {stars.map((s, i) => (
        <circle
          key={i}
          cx={s.x + "%"}
          cy={s.y + "%"}
          r={s.r}
          fill="white"
          opacity={s.op}
          style={twinkle ? {
            animation: `tw 4s ease-in-out ${s.delay}s infinite`,
          } : {}}
        />
      ))}
      <style>{`@keyframes tw { 0%,100%{opacity:.2} 50%{opacity:.9} }`}</style>
    </svg>
  );
}

/* ──────────────────────────────────────────────────────────
   Kicker label
   ────────────────────────────────────────────────────────── */
function Kicker({ children, accent = false }) {
  return (
    <div className="kicker" style={accent ? { color: "var(--accent)" } : undefined}>
      {children}
    </div>
  );
}

/* ──────────────────────────────────────────────────────────
   Divider with glyph
   ────────────────────────────────────────────────────────── */
function DividerGlyph({ glyph = "·  ·  ·" }) {
  return (
    <div className="divider-glyph">
      <span className="glyph">{glyph}</span>
    </div>
  );
}

/* ──────────────────────────────────────────────────────────
   Field label + input (display-only)
   ────────────────────────────────────────────────────────── */
function Field({ label, value, hint, multiline = false, suffix = null }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
      <label style={{
        fontFamily: "var(--sans)", fontSize: 12,
        color: "var(--ink-3)", letterSpacing: "0.08em", textTransform: "uppercase",
      }}>{label}</label>
      <div style={{
        background: "var(--bg-soft)",
        border: "1px solid var(--rule)",
        borderRadius: 12,
        padding: multiline ? "14px 16px" : "12px 16px",
        color: "var(--ink)",
        fontFamily: "var(--serif)",
        fontSize: 16,
        lineHeight: 1.6,
        minHeight: multiline ? 80 : "auto",
        display: "flex",
        alignItems: multiline ? "flex-start" : "center",
        justifyContent: "space-between",
        gap: 12,
      }}>
        <span>{value}</span>
        {suffix && <span className="t-meta">{suffix}</span>}
      </div>
      {hint && <div className="t-caption" style={{ fontSize: 12 }}>{hint}</div>}
    </div>
  );
}

/* ──────────────────────────────────────────────────────────
   ToneHost — wraps a screen with [data-tone] + [data-mode]
   so artboards can preview different palettes side-by-side
   ────────────────────────────────────────────────────────── */
function ToneHost({ tone = "solemn", mode = "dark", density = "default", style = {}, children }) {
  return (
    <div
      data-tone={tone}
      data-mode={mode}
      data-density={density}
      className="tone-host"
      style={{ minHeight: "100%", height: "100%", ...style }}
    >
      {children}
    </div>
  );
}

/* ──────────────────────────────────────────────────────────
   Tiny iconography (line, 1.4 stroke, currentColor)
   ────────────────────────────────────────────────────────── */
const Icon = {
  Mic: ({ size = 18 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round">
      <rect x="9" y="3" width="6" height="12" rx="3" /><path d="M5 11a7 7 0 0 0 14 0M12 18v3" />
    </svg>
  ),
  Play: ({ size = 18 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor"><path d="M8 5l12 7-12 7z"/></svg>
  ),
  Pen: ({ size = 18 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round">
      <path d="M14 4l6 6-12 12H2v-6z"/>
    </svg>
  ),
  Photo: ({ size = 18 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="11" r="2"/><path d="M3 17l5-5 4 4 3-3 6 6"/>
    </svg>
  ),
  Send: ({ size = 18 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 11l18-8-8 18-2-8z"/>
    </svg>
  ),
  Heart: ({ size = 18 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 20s-7-4.5-9-9.5C1 6.5 4 3 7.5 3 9.5 3 11 4 12 5.5 13 4 14.5 3 16.5 3 20 3 23 6.5 21 10.5c-2 5-9 9.5-9 9.5z"/>
    </svg>
  ),
  Bell: ({ size = 18 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round">
      <path d="M6 16V11a6 6 0 0 1 12 0v5l1.5 2h-15z"/><path d="M10 21h4"/>
    </svg>
  ),
  Lock: ({ size = 18 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round">
      <rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>
    </svg>
  ),
  Plus: ({ size = 18 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round">
      <path d="M12 5v14M5 12h14"/>
    </svg>
  ),
  Check: ({ size = 18 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <path d="M5 12l5 5 9-12"/>
    </svg>
  ),
  Arrow: ({ size = 18 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round">
      <path d="M5 12h14M13 5l7 7-7 7"/>
    </svg>
  ),
  Doc: ({ size = 18 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round">
      <path d="M6 3h9l5 5v13H6z"/><path d="M14 3v6h6"/>
    </svg>
  ),
  Calendar: ({ size = 18 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>
    </svg>
  ),
  Frame: ({ size = 18 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round">
      <rect x="4" y="3" width="16" height="18" rx="1"/><rect x="7" y="6" width="10" height="12"/>
    </svg>
  ),
  Quote: ({ size = 18 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round">
      <path d="M7 7v5h5l-3 6M14 7v5h5l-3 6"/>
    </svg>
  ),
};

Object.assign(window, {
  Logomark, TopNav, Photo, PortraitSilhouette, Starfield,
  Kicker, DividerGlyph, Field, ToneHost, Icon,
});
